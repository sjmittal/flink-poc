package com.rh.entity;

public class LiteSwatch {
  public String swatchId;
  public String displayName;
  public String rhrRepeatImageRef;
}
