package com.rh.entity;

import com.rh.entity.common.Audit;

public class Swatch extends Audit {

  public String id;
  public String swatchId;
  public String displayName;
  public String adminName;
  public String swatchImageRef;
}
