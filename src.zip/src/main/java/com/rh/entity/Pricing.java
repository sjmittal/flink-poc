package com.rh.entity;

import com.rh.entity.common.Audit;

public class Pricing extends Audit {

  public String id;
  public String fullSkuId;
  public String countryCode;
  public String currencyCode;
  public String sellToCountryRegion;
  public String region;
  public Double memberPrice;
  public Double contractPrice;
  public Double tradePrice;
  public String saleStatus;
  public Double listPrice;
  public Double salePrice;
  public Double memberListPrice;
  public Double retailOriginalPrice;
  public Double retailCurrentPrice;
  public Double outletOriginalPrice;
  public Double price;
  public String effectiveStartDate;
}
