package com.rh.entity;

public class LiteOption {
  public String optionId;
  public String optionValue;
  public String adminName;
  public String optionTypeId;
  public String optionTypeValue;
}
