package com.rh.entity;

import com.rh.entity.common.Audit;

public class Option extends Audit {
  public String id;
  public String optionId;
  public String optionValue;
  public String adminName;
  public String optionTypeId;
  public String optionTypeValue;
}
