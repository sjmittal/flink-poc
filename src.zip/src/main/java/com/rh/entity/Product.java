package com.rh.entity;

import com.rh.entity.common.Audit;

public class Product extends Audit {

  public String id;
  public String productId;
  public String productDisplayName;
  public String adminName;
  public String imageToken;
  public String galleryDescription;
  public String keywords;
  public String source;
  public String startDate;
  public String endDate;
  public String category;
}
