package com.rh.entity;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;

@TypeInfo(EnrichedProductSku.EnrichedProductSkuTypeInfoFactory.class)
public class EnrichedProductSku {
  // common fields
  public String productId;
  public String region;
  public String fullSkuId;

  // product fields
  public String productDisplayName;
  public String adminName;
  public String imageToken;
  public String galleryDescription;
  public String keywords;
  public String source;
  public String startDate;
  public String endDate;
  public String category;
  public boolean productUpdated;

  // swatch fields
  public List<LiteSwatch> swatches = new ArrayList<>();
  public boolean swatchUpdated;

  // options fields
  public List<LiteOption> options = new ArrayList<>();
  public boolean optionUpdated;

  // swatch option map
  public Map<String, List<String>> swatchOptions = new HashMap<>();
  public boolean swatchOptionUpdated;

  // options colorization map
  //  public Map<Integer, String> colorizationMap = new HashMap<>();

  public EnrichedProductSku() {}

  public EnrichedProductSku(String productId, String fullSkuId, String region, Product product) {
    this.productId = productId;
    this.fullSkuId = fullSkuId;
    this.region = region;

    this.productDisplayName = product.productDisplayName;
    this.adminName = product.adminName;
    this.imageToken = product.imageToken;
    this.galleryDescription = product.galleryDescription;
    this.keywords = product.keywords;
    this.source = product.source;
    this.startDate = product.startDate;
    this.endDate = product.endDate;
    this.category = product.category;

    this.productUpdated = true;
  }

  public EnrichedProductSku(
      String productId, String fullSkuId, String region, String swatchId, Swatch swatch) {
    this.productId = productId;
    this.fullSkuId = fullSkuId;
    this.region = region;

    LiteSwatch s = new LiteSwatch();
    s.swatchId = swatchId;
    s.displayName = swatch.displayName;
    s.rhrRepeatImageRef = swatch.rhrRepeatImageRef;
    swatches.add(s);

    this.swatchUpdated = true;
  }

  public EnrichedProductSku(
      String productId, String fullSkuId, String region, String optionId, Option option) {
    this.productId = productId;
    this.fullSkuId = fullSkuId;
    this.region = region;

    LiteOption o = new LiteOption();
    o.optionId = optionId;
    o.optionTypeId = option.optionTypeId;
    o.optionValue = option.optionValue;
    o.optionTypeValue = option.optionTypeValue;
    options.add(o);

    this.optionUpdated = true;
  }

  public EnrichedProductSku(
      String productId, String fullSkuId, String region, String swatchId, SwatchOption swatchOpt) {
    this.productId = productId;
    this.fullSkuId = fullSkuId;
    this.region = region;

    swatchOptions.put(swatchId, swatchOpt.optionIds);

    this.swatchOptionUpdated = true;
  }

  public EnrichedProductSku update(EnrichedProductSku enrichedProductSku) {
    if (enrichedProductSku.productUpdated) {
      this.productDisplayName = enrichedProductSku.productDisplayName;
      this.adminName = enrichedProductSku.adminName;
      this.imageToken = enrichedProductSku.imageToken;
      this.galleryDescription = enrichedProductSku.galleryDescription;
      this.keywords = enrichedProductSku.keywords;
      this.source = enrichedProductSku.source;
      this.startDate = enrichedProductSku.startDate;
      this.endDate = enrichedProductSku.endDate;
      this.category = enrichedProductSku.category;
    }
    if (enrichedProductSku.swatchUpdated) {
      for (LiteSwatch swatch : enrichedProductSku.swatches) {
        Optional<LiteSwatch> maybeSwatch =
            this.swatches.stream().filter(s -> s.swatchId.equals(swatch.swatchId)).findAny();
        if (maybeSwatch.isPresent()) {
          LiteSwatch s = maybeSwatch.get();
          s.rhrRepeatImageRef = swatch.rhrRepeatImageRef;
          s.displayName = swatch.displayName;
        } else {
          this.swatches.add(swatch);
        }
      }
    }

    if (enrichedProductSku.optionUpdated) {
      for (LiteOption option : enrichedProductSku.options) {
        Optional<LiteOption> maybeOption =
            this.options.stream().filter(o -> o.optionId.equals(option.optionId)).findAny();
        if (maybeOption.isPresent()) {
          LiteOption o = maybeOption.get();
          o.optionValue = option.optionValue;
          o.optionTypeId = option.optionTypeId;
          o.optionTypeValue = option.optionTypeValue;
        } else {
          this.options.add(option);
        }
      }
    }

    if (enrichedProductSku.swatchOptionUpdated) {
      this.swatchOptions.putAll(enrichedProductSku.swatchOptions);
    }

    return this;
  }

  //  private void compute() {
  //    Set<Set<String>> combinations =
  //        Sets.powerSet(this.swatches.stream().map(s -> s.swatchId).collect(Collectors.toSet()));
  //    combinations.stream()
  //        .filter(set -> set.size() > 0)
  //        .forEach(
  //            set -> {
  //              String url =
  //              set.stream()
  //                  .map(
  //                      s ->
  //                          this.swatches.stream()
  //                              .filter(swatch -> swatch.swatchId.equals(s))
  //                              .findAny()
  //                              .map(swatch -> swatch.rhrRepeatImageRef)
  //                              .orElse(""))
  //                  .reduce("", (combinedUrl, partUrl) -> combinedUrl + partUrl);
  //              this.colorizationMap.put(set.hashCode(), url);
  //            });
  //  }

  public static class EnrichedProductSkuTypeInfoFactory
      extends TypeInfoFactory<EnrichedProductSku> {
    @Override
    public TypeInformation<EnrichedProductSku> createTypeInfo(
        Type t, Map<String, TypeInformation<?>> genericParameters) {
      Map<String, TypeInformation<?>> fields =
          new HashMap<String, TypeInformation<?>>() {
            {
              put("productId", Types.STRING);
              put("fullSkuId", Types.STRING);
              put("region", Types.STRING);
              put("productDisplayName", Types.STRING);
              put("adminName", Types.STRING);
              put("imageToken", Types.STRING);
              put("galleryDescription", Types.STRING);
              put("keywords", Types.STRING);
              put("source", Types.STRING);
              put("startDate", Types.STRING);
              put("endDate", Types.STRING);
              put("category", Types.STRING);
              put("swatches", Types.LIST(Types.POJO(LiteSwatch.class)));
              put("options", Types.LIST(Types.POJO(LiteOption.class)));
              put("swatchOptions", Types.MAP(Types.STRING, Types.LIST(Types.STRING)));
              //              put("colorizationMap", Types.MAP(Types.INT, Types.STRING));
              put("productUpdated", Types.BOOLEAN);
              put("swatchUpdated", Types.BOOLEAN);
              put("optionUpdated", Types.BOOLEAN);
              put("swatchOptionUpdated", Types.BOOLEAN);
            }
          };
      return Types.POJO(EnrichedProductSku.class, fields);
    }
  }
}
