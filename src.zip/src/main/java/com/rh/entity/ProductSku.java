package com.rh.entity;

import com.rh.entity.common.Audit;
import com.rh.entity.common.AutomationType;
import com.rh.entity.common.SkuInfo;
import com.rh.entity.common.UniqueColorCode;
import com.rh.entity.common.UniqueItemNumber;
import com.rh.entity.common.UniqueSizeCode;
import com.rh.sku.utils.data.flink.serde.SetTypeInfo;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;

@TypeInfo(ProductSku.ProductSkuTypeInfoFactory.class)
public class ProductSku extends Audit {

  public String id;
  public String productId;
  public String region;
  public Map<String, List<SkuInfo>> itemFullSkuIds;
  public List<UniqueItemNumber> uniqueItemNumbers;
  public List<UniqueColorCode> uniqueColorCodes;
  public List<UniqueSizeCode> uniqueSizeCodes;
  public Set<String> aggregatedWebMerchants;
  public String automationExternalId;
  public AutomationType automationType;

  public static class ProductSkuTypeInfoFactory extends TypeInfoFactory<ProductSku> {
    @Override
    public TypeInformation<ProductSku> createTypeInfo(
        Type t, Map<String, TypeInformation<?>> genericParameters) {
      Map<String, TypeInformation<?>> fields =
          new HashMap<String, TypeInformation<?>>() {
            {
              put("id", Types.STRING);
              put("productId", Types.STRING);
              put("region", Types.STRING);
              put("itemFullSkuIds", Types.MAP(Types.STRING, Types.LIST(Types.POJO(SkuInfo.class))));
              put("uniqueItemNumbers", Types.LIST(Types.POJO(UniqueItemNumber.class)));
              put("uniqueColorCodes", Types.LIST(Types.POJO(UniqueColorCode.class)));
              put("uniqueSizeCodes", Types.LIST(Types.POJO(UniqueSizeCode.class)));
              put("aggregatedWebMerchants", new SetTypeInfo<>(Types.STRING));
              put("automationExternalId", Types.STRING);
              put("automationType", Types.ENUM(AutomationType.class));
            }
          };
      return Types.POJO(ProductSku.class, fields);
    }
  }
}
