package com.rh.entity;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;

@TypeInfo(EnrichedSku.EnrichedSkuTypeInfoFactory.class)
public class EnrichedSku {

  // common fields
  public String fullSkuId;
  public String region;

  // sku fields
  public String webPurchasable;
  public String dropship;
  public String itemNumber;
  public String colorCode;
  public String itemDescription;
  public String department;
  public String sellToCountryRegionCode;
  public String mddFabric;
  public String mddColor;
  public String mddFunction;
  public String mddDetail;
  public String mddFrame;
  public String mddDepth;
  public String mddItemSize;
  public String mddFill;
  public String mddSecondaryColor;
  public String mddItemStyle;
  public String mddCollection;
  public boolean skuUpdated;

  // pricing fields
  public String countryCode;
  public String currencyCode;
  public String sellToCountryRegion;
  public Double memberPrice;
  public Double contractPrice;
  public Double tradePrice;
  public String saleStatus;
  public Double listPrice;
  public Double salePrice;
  public Double memberListPrice;
  public Double retailOriginalPrice;
  public Double retailCurrentPrice;
  public Double outletOriginalPrice;
  public Double price;
  public String effectiveStartDate;
  public boolean pricingUpdated;

  // inventory fields
  public List<LiteLocation> locations;
  public Boolean inStock;
  public String availablityStatus;
  public String availablityStatusMsg;
  public boolean inventoryUpdated;

  public EnrichedSku() {}

  public EnrichedSku(EpimSku sku) {
    this.fullSkuId = sku.fullSkuId;
    this.region = sku.region;

    this.webPurchasable = sku.webPurchasable;
    this.dropship = sku.dropship;
    this.itemNumber = sku.itemNumber;
    this.colorCode = sku.colorCode;
    this.itemDescription = sku.itemDescription;
    this.department = sku.department;
    this.sellToCountryRegionCode = sku.sellToCountryRegionCode;
    this.mddFabric = sku.mddFabric;
    this.mddColor = sku.mddColor;
    this.mddFunction = sku.mddFunction;
    this.mddDetail = sku.mddDetail;
    this.mddFrame = sku.mddFrame;
    this.mddDepth = sku.mddDepth;
    this.mddItemSize = sku.mddItemSize;
    this.mddFill = sku.mddFill;
    this.mddSecondaryColor = sku.mddSecondaryColor;
    this.mddItemStyle = sku.mddItemStyle;
    this.mddCollection = sku.mddCollection;

    this.skuUpdated = true;
  }

  public EnrichedSku(Pricing pricing) {
    this.fullSkuId = pricing.fullSkuId;
    this.region = pricing.region;

    this.countryCode = pricing.countryCode;
    this.currencyCode = pricing.currencyCode;
    this.sellToCountryRegion = pricing.sellToCountryRegion;
    this.memberPrice = pricing.memberPrice;
    this.contractPrice = pricing.contractPrice;
    this.tradePrice = pricing.tradePrice;
    this.saleStatus = pricing.saleStatus;
    this.listPrice = pricing.listPrice;
    this.salePrice = pricing.salePrice;
    this.memberListPrice = pricing.memberListPrice;
    this.retailOriginalPrice = pricing.retailOriginalPrice;
    this.retailCurrentPrice = pricing.retailCurrentPrice;
    this.outletOriginalPrice = pricing.outletOriginalPrice;
    this.price = pricing.price;
    this.effectiveStartDate = pricing.effectiveStartDate;

    this.pricingUpdated = true;
  }

  public EnrichedSku(Inventory inventory) {
    this.fullSkuId = inventory.fullSkuId;
    this.region = inventory.region;

    if (inventory.locations != null) {
      this.locations =
          inventory.locations.stream()
              .map(
                  l -> {
                    LiteLocation ll = new LiteLocation();
                    ll.dcId = l.dcId;
                    ll.onHand = l.onHand;
                    ll.madeToOrder = l.madeToOrder;
                    return ll;
                  })
              .collect(Collectors.toList());
    }

    this.inStock = inventory.inStock;
    this.availablityStatus = inventory.availablityStatus;
    this.availablityStatusMsg = inventory.availablityStatusMsg;

    this.inventoryUpdated = true;
  }

  public EnrichedSku update(EnrichedSku enrichedSku) {
    if (enrichedSku.skuUpdated) {
      this.webPurchasable = enrichedSku.webPurchasable;
      this.dropship = enrichedSku.dropship;
      this.itemNumber = enrichedSku.itemNumber;
      this.colorCode = enrichedSku.colorCode;
      this.itemDescription = enrichedSku.itemDescription;
      this.department = enrichedSku.department;
      this.sellToCountryRegionCode = enrichedSku.sellToCountryRegionCode;
      this.mddFabric = enrichedSku.mddFabric;
      this.mddColor = enrichedSku.mddColor;
      this.mddFunction = enrichedSku.mddFunction;
      this.mddDetail = enrichedSku.mddDetail;
      this.mddFrame = enrichedSku.mddFrame;
      this.mddDepth = enrichedSku.mddDepth;
      this.mddItemSize = enrichedSku.mddItemSize;
      this.mddFill = enrichedSku.mddFill;
      this.mddSecondaryColor = enrichedSku.mddSecondaryColor;
      this.mddItemStyle = enrichedSku.mddItemStyle;
      this.mddCollection = enrichedSku.mddCollection;

      this.skuUpdated = true;
    }
    if (enrichedSku.pricingUpdated) {
      this.countryCode = enrichedSku.countryCode;
      this.currencyCode = enrichedSku.currencyCode;
      this.sellToCountryRegion = enrichedSku.sellToCountryRegion;
      this.memberPrice = enrichedSku.memberPrice;
      this.contractPrice = enrichedSku.contractPrice;
      this.tradePrice = enrichedSku.tradePrice;
      this.saleStatus = enrichedSku.saleStatus;
      this.listPrice = enrichedSku.listPrice;
      this.salePrice = enrichedSku.salePrice;
      this.memberListPrice = enrichedSku.memberListPrice;
      this.retailOriginalPrice = enrichedSku.retailOriginalPrice;
      this.retailCurrentPrice = enrichedSku.retailCurrentPrice;
      this.outletOriginalPrice = enrichedSku.outletOriginalPrice;
      this.price = enrichedSku.price;
      this.effectiveStartDate = enrichedSku.effectiveStartDate;

      this.pricingUpdated = true;
    }
    if (enrichedSku.inventoryUpdated) {
      this.locations = enrichedSku.locations;
      this.inStock = enrichedSku.inStock;
      this.availablityStatus = enrichedSku.availablityStatus;
      this.availablityStatusMsg = enrichedSku.availablityStatusMsg;

      this.inventoryUpdated = true;
    }

    return this;
  }

  public static class EnrichedSkuTypeInfoFactory extends TypeInfoFactory<EnrichedSku> {
    @Override
    public TypeInformation<EnrichedSku> createTypeInfo(
        Type t, Map<String, TypeInformation<?>> genericParameters) {
      Map<String, TypeInformation<?>> fields =
          new HashMap<String, TypeInformation<?>>() {
            {
              put("fullSkuId", Types.STRING);
              put("region", Types.STRING);
              put("webPurchasable", Types.STRING);
              put("dropship", Types.STRING);
              put("itemNumber", Types.STRING);
              put("colorCode", Types.STRING);
              put("itemDescription", Types.STRING);
              put("department", Types.STRING);
              put("sellToCountryRegionCode", Types.STRING);
              put("mddFabric", Types.STRING);
              put("mddColor", Types.STRING);
              put("mddFunction", Types.STRING);
              put("mddDetail", Types.STRING);
              put("mddFrame", Types.STRING);
              put("mddDepth", Types.STRING);
              put("mddItemSize", Types.STRING);
              put("mddFill", Types.STRING);
              put("mddSecondaryColor", Types.STRING);
              put("mddItemStyle", Types.STRING);
              put("mddCollection", Types.STRING);
              put("countryCode", Types.STRING);
              put("currencyCode", Types.STRING);
              put("sellToCountryRegion", Types.STRING);
              put("retailOriginalPrice", Types.DOUBLE);
              put("retailCurrentPrice", Types.DOUBLE);
              put("tradePrice", Types.DOUBLE);
              put("saleStatus", Types.STRING);
              put("listPrice", Types.DOUBLE);
              put("salePrice", Types.DOUBLE);
              put("memberListPrice", Types.DOUBLE);
              put("memberPrice", Types.DOUBLE);
              put("contractPrice", Types.DOUBLE);
              put("outletOriginalPrice", Types.DOUBLE);
              put("price", Types.DOUBLE);
              put("effectiveStartDate", Types.STRING);
              put("locations", Types.LIST(Types.POJO(LiteLocation.class)));
              put("inStock", Types.BOOLEAN);
              put("availablityStatus", Types.STRING);
              put("availablityStatusMsg", Types.STRING);
              put("skuUpdated", Types.BOOLEAN);
              put("pricingUpdated", Types.BOOLEAN);
              put("inventoryUpdated", Types.BOOLEAN);
            }
          };
      return Types.POJO(EnrichedSku.class, fields);
    }
  }
}
