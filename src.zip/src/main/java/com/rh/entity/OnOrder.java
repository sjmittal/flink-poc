package com.rh.entity;

public class OnOrder {

  public Integer quantity;
  public String poNumber;
}
