package com.rh.entity;

public class LiteLocation {
  public Integer dcId;
  public Integer onHand;
  public Integer madeToOrder;
}
