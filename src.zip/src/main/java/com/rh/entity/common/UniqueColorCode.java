package com.rh.entity.common;

import com.rh.sku.utils.data.flink.serde.SetTypeInfo;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;

@TypeInfo(UniqueColorCode.UniqueColorCodeTypeInfoFactory.class)
public class UniqueColorCode {

  public String colorCode;
  public Set<String> swatchIds;

  public static class UniqueColorCodeTypeInfoFactory extends TypeInfoFactory<UniqueColorCode> {
    @Override
    public TypeInformation<UniqueColorCode> createTypeInfo(
        Type t, Map<String, TypeInformation<?>> genericParameters) {
      Map<String, TypeInformation<?>> fields =
          new HashMap<String, TypeInformation<?>>() {
            {
              put("colorCode", Types.STRING);
              put("swatchIds", new SetTypeInfo<>(Types.STRING));
            }
          };
      return Types.POJO(UniqueColorCode.class, fields);
    }
  }
}
