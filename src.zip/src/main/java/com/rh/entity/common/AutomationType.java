package com.rh.entity.common;

public enum AutomationType {
  INCREMENTAL("INCREMENTAL"),
  FULL("FULL");

  private final String automationTypeName;

  AutomationType(String automationTypeName) {
    this.automationTypeName = automationTypeName;
  }
}
