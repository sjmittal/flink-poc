package com.rh.entity.common;

public class Audit {

  public String createdBy;
  public String updatedBy;
}
