package com.rh.entity.common;

import com.rh.sku.utils.data.flink.serde.SetTypeInfo;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;

@TypeInfo(SkuInfo.SkuInfoTypeInfoFactory.class)
public class SkuInfo {
  public String fullSkuId;
  public Set<String> totalOptionIds;
  public Set<String> totalSwatchIds;
  public String department;

  public static class SkuInfoTypeInfoFactory extends TypeInfoFactory<SkuInfo> {
    @Override
    public TypeInformation<SkuInfo> createTypeInfo(
        Type t, Map<String, TypeInformation<?>> genericParameters) {
      Map<String, TypeInformation<?>> fields =
          new HashMap<String, TypeInformation<?>>() {
            {
              put("fullSkuId", Types.STRING);
              put("totalOptionIds", new SetTypeInfo<>(Types.STRING));
              put("totalSwatchIds", new SetTypeInfo<>(Types.STRING));
              put("department", Types.STRING);
            }
          };
      return Types.POJO(SkuInfo.class, fields);
    }
  }
}
