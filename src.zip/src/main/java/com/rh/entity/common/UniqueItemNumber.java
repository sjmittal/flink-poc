package com.rh.entity.common;

import com.rh.sku.utils.data.flink.serde.SetTypeInfo;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;

@TypeInfo(UniqueItemNumber.UniqueItemNumberTypeInfoFactory.class)
public class UniqueItemNumber {

  public String itemNumber;
  public Set<String> itemNumberOptionIds;
  public String swatchId;

  public static class UniqueItemNumberTypeInfoFactory extends TypeInfoFactory<UniqueItemNumber> {
    @Override
    public TypeInformation<UniqueItemNumber> createTypeInfo(
        Type t, Map<String, TypeInformation<?>> genericParameters) {
      Map<String, TypeInformation<?>> fields =
          new HashMap<String, TypeInformation<?>>() {
            {
              put("itemNumber", Types.STRING);
              put("itemNumberOptionIds", new SetTypeInfo<>(Types.STRING));
              put("swatchId", Types.STRING);
            }
          };
      return Types.POJO(UniqueItemNumber.class, fields);
    }
  }
}
