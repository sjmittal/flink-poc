package com.rh.entity;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;

@TypeInfo(Location.LocationTypeInfoFactory.class)
public class Location {

  public Integer dcId;
  public Integer onHand;
  public Integer madeToOrder;
  public List<OnOrder> onOrder;
  public Boolean allowable;
  public String availablityStatus;
  public String availablityStatusMsg;

  public static class LocationTypeInfoFactory extends TypeInfoFactory<Location> {
    @Override
    public TypeInformation<Location> createTypeInfo(
        Type t, Map<String, TypeInformation<?>> genericParameters) {
      Map<String, TypeInformation<?>> fields =
          new HashMap<String, TypeInformation<?>>() {
            {
              put("dcId", Types.INT);
              put("onHand", Types.INT);
              put("madeToOrder", Types.INT);
              put("onOrder", Types.LIST(Types.POJO(OnOrder.class)));
              put("allowable", Types.BOOLEAN);
              put("availablityStatus", Types.STRING);
              put("availablityStatusMsg", Types.STRING);
            }
          };
      return Types.POJO(Location.class, fields);
    }
  }
}
