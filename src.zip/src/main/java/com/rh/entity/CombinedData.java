package com.rh.entity;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;

@TypeInfo(CombinedData.CombinedDataTypeInfoFactory.class)
public class CombinedData {
  // common fields
  public String productId;
  public String region;
  public String fullSkuId;

  // product fields
  public String productDisplayName;
  public String adminName;
  public String imageToken;
  public String galleryDescription;
  public String keywords;
  public String source;
  public String startDate;
  public String endDate;
  public String category;

  // swatch fields
  public List<LiteSwatch> swatches;

  // options fields
  public List<LiteOption> options;

  // swatch option map
  public Map<String, List<String>> swatchOptions;

  // sku fields
  public String webPurchasable;
  public String dropship;
  public String itemNumber;
  public String colorCode;
  public String itemDescription;
  public String department;
  public String sellToCountryRegionCode;
  public String mddFabric;
  public String mddColor;
  public String mddFunction;
  public String mddDetail;
  public String mddFrame;
  public String mddDepth;
  public String mddItemSize;
  public String mddFill;
  public String mddSecondaryColor;
  public String mddItemStyle;
  public String mddCollection;

  // pricing fields
  public String countryCode;
  public String currencyCode;
  public String sellToCountryRegion;
  public Double memberPrice;
  public Double contractPrice;
  public Double tradePrice;
  public String saleStatus;
  public Double listPrice;
  public Double salePrice;
  public Double memberListPrice;
  public Double retailOriginalPrice;
  public Double retailCurrentPrice;
  public Double outletOriginalPrice;
  public Double price;
  public String effectiveStartDate;

  // inventory fields
  public List<LiteLocation> locations;
  public Boolean inStock;
  public String availablityStatus;
  public String availablityStatusMsg;

  public static class CombinedDataTypeInfoFactory extends TypeInfoFactory<CombinedData> {
    @Override
    public TypeInformation<CombinedData> createTypeInfo(
        Type t, Map<String, TypeInformation<?>> genericParameters) {
      Map<String, TypeInformation<?>> fields =
          new HashMap<String, TypeInformation<?>>() {
            {
              put("productId", Types.STRING);
              put("fullSkuId", Types.STRING);
              put("region", Types.STRING);
              put("productDisplayName", Types.STRING);
              put("adminName", Types.STRING);
              put("imageToken", Types.STRING);
              put("galleryDescription", Types.STRING);
              put("keywords", Types.STRING);
              put("source", Types.STRING);
              put("startDate", Types.STRING);
              put("endDate", Types.STRING);
              put("category", Types.STRING);
              put("swatches", Types.LIST(Types.POJO(LiteSwatch.class)));
              put("options", Types.LIST(Types.POJO(LiteOption.class)));
              put("swatchOptions", Types.MAP(Types.STRING, Types.LIST(Types.STRING)));
              put("webPurchasable", Types.STRING);
              put("dropship", Types.STRING);
              put("itemNumber", Types.STRING);
              put("colorCode", Types.STRING);
              put("itemDescription", Types.STRING);
              put("department", Types.STRING);
              put("sellToCountryRegionCode", Types.STRING);
              put("mddFabric", Types.STRING);
              put("mddColor", Types.STRING);
              put("mddFunction", Types.STRING);
              put("mddDetail", Types.STRING);
              put("mddFrame", Types.STRING);
              put("mddDepth", Types.STRING);
              put("mddItemSize", Types.STRING);
              put("mddFill", Types.STRING);
              put("mddSecondaryColor", Types.STRING);
              put("mddItemStyle", Types.STRING);
              put("mddCollection", Types.STRING);
              put("countryCode", Types.STRING);
              put("currencyCode", Types.STRING);
              put("sellToCountryRegion", Types.STRING);
              put("retailOriginalPrice", Types.DOUBLE);
              put("retailCurrentPrice", Types.DOUBLE);
              put("tradePrice", Types.DOUBLE);
              put("saleStatus", Types.STRING);
              put("listPrice", Types.DOUBLE);
              put("salePrice", Types.DOUBLE);
              put("memberListPrice", Types.DOUBLE);
              put("memberPrice", Types.DOUBLE);
              put("contractPrice", Types.DOUBLE);
              put("outletOriginalPrice", Types.DOUBLE);
              put("price", Types.DOUBLE);
              put("effectiveStartDate", Types.STRING);
              put("locations", Types.LIST(Types.POJO(LiteLocation.class)));
              put("inStock", Types.BOOLEAN);
              put("availablityStatus", Types.STRING);
              put("availablityStatusMsg", Types.STRING);
            }
          };
      return Types.POJO(CombinedData.class, fields);
    }
  }
}
