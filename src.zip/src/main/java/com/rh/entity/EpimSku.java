package com.rh.entity;

import com.rh.entity.common.Audit;

public class EpimSku extends Audit {

  public String id;
  public String webPurchasable;
  public String dropship;
  public String itemNumber;
  public String colorCode;
  public String itemDescription;
  public String region;
  public String fullSkuId;
  public String department;
  public String sellToCountryRegionCode;
  public String mddFabric;
  public String mddColor;
  public String mddFunction;
  public String mddDetail;
  public String mddFrame;
  public String mddDepth;
  public String mddItemSize;
  public String mddFill;
  public String mddSecondaryColor;
  public String mddItemStyle;
  public String mddCollection;
}
