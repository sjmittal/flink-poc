package com.rh.entity;

import com.rh.entity.common.Audit;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;

@TypeInfo(Inventory.InventoryTypeInfoFactory.class)
public class Inventory extends Audit {

  public String id;
  public String fullSkuId;
  public List<Location> locations;
  public Boolean inStock;
  public String region;
  public String availablityStatus;
  public String availablityStatusMsg;

  public static class InventoryTypeInfoFactory extends TypeInfoFactory<Inventory> {
    @Override
    public TypeInformation<Inventory> createTypeInfo(
        Type t, Map<String, TypeInformation<?>> genericParameters) {
      Map<String, TypeInformation<?>> fields =
          new HashMap<String, TypeInformation<?>>() {
            {
              put("id", Types.STRING);
              put("fullSkuId", Types.STRING);
              put("locations", Types.LIST(Types.POJO(Location.class)));
              put("inStock", Types.BOOLEAN);
              put("region", Types.STRING);
              put("availablityStatus", Types.STRING);
              put("availablityStatusMsg", Types.STRING);
              put("createdBy", Types.STRING);
              put("updatedBy", Types.STRING);
            }
          };
      return Types.POJO(Inventory.class, fields);
    }
  }
}
