package com.rh.entity;

import com.rh.entity.common.Audit;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.flink.api.common.typeinfo.TypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInfoFactory;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;

@TypeInfo(SwatchOption.SwatchOptionTypeInfoFactory.class)
public class SwatchOption extends Audit {
  public String id;
  public String swatchId;
  public List<String> optionIds;

  public static class SwatchOptionTypeInfoFactory extends TypeInfoFactory<SwatchOption> {
    @Override
    public TypeInformation<SwatchOption> createTypeInfo(
        Type t, Map<String, TypeInformation<?>> genericParameters) {
      Map<String, TypeInformation<?>> fields =
          new HashMap<String, TypeInformation<?>>() {
            {
              put("swatchId", Types.STRING);
              put("optionIds", Types.LIST(Types.STRING));
            }
          };
      return Types.POJO(SwatchOption.class, fields);
    }
  }
}
