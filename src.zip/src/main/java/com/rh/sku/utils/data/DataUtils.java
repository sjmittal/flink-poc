package com.rh.sku.utils.data;

import com.clickhouse.data.ClickHouseValues;
import com.rh.entity.LiteLocation;
import com.rh.entity.LiteOption;
import com.rh.entity.LiteSwatch;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class DataUtils {

  private static final SimpleDateFormat inputFormat = new SimpleDateFormat("MM-dd-yyyy hh:mm:ss");
  private static final SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

  public static String toDateTime(String src) {
    if (src == null) {
      return null;
    }
    Date d = null;
    try {
      d = inputFormat.parse(src);
    } catch (ParseException e) {
      return null;
    }
    return outputFormat.format(d);
  }

  public static String toNestedSwatchSql(List<LiteSwatch> swatches) {
    if (swatches == null || swatches.isEmpty()) {
      return ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR;
    }

    Object[] swatchIds = new Object[swatches.size()];
    Object[] displayNames = new Object[swatches.size()];
    Object[] rhrRepeatImageRefs = new Object[swatches.size()];

    int i = 0;
    for (LiteSwatch swatch : swatches) {
      swatchIds[i] = swatch.swatchId;
      displayNames[i] = swatch.displayName;
      rhrRepeatImageRefs[i] = swatch.rhrRepeatImageRef;

      i++;
    }
    return ClickHouseValues.convertToSqlExpression(swatchIds)
        + ","
        + ClickHouseValues.convertToSqlExpression(displayNames)
        + ","
        + ClickHouseValues.convertToSqlExpression(rhrRepeatImageRefs);
  }

  public static String toNestedOptionSql(List<LiteOption> options) {
    if (options == null || options.isEmpty()) {
      return ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR;
    }

    Object[] optionIds = new Object[options.size()];
    Object[] optionValues = new Object[options.size()];
    Object[] optionTypeIds = new Object[options.size()];
    Object[] optionTypeValues = new Object[options.size()];

    int i = 0;
    for (LiteOption option : options) {
      optionIds[i] = option.optionId;
      optionValues[i] = option.optionValue;
      optionTypeIds[i] = option.optionTypeId;
      optionTypeValues[i] = option.optionTypeValue;

      i++;
    }
    return ClickHouseValues.convertToSqlExpression(optionIds)
        + ","
        + ClickHouseValues.convertToSqlExpression(optionValues)
        + ","
        + ClickHouseValues.convertToSqlExpression(optionTypeIds)
        + ","
        + ClickHouseValues.convertToSqlExpression(optionTypeValues);
  }

  public static String toNestedLocationSql(List<LiteLocation> locations) {
    if (locations == null || locations.isEmpty()) {
      return ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR;
    }

    Object[] dcIds = new Object[locations.size()];
    Object[] onHands = new Object[locations.size()];
    Object[] madeToOrders = new Object[locations.size()];

    int i = 0;
    for (LiteLocation location : locations) {
      dcIds[i] = location.dcId;
      onHands[i] = location.onHand;
      madeToOrders[i] = location.madeToOrder;

      i++;
    }
    return ClickHouseValues.convertToSqlExpression(dcIds)
        + ","
        + ClickHouseValues.convertToSqlExpression(onHands)
        + ","
        + ClickHouseValues.convertToSqlExpression(madeToOrders);
  }

  public static String toNestedSql(Map<String, List<String>> swatchOptions) {
    if (swatchOptions == null || swatchOptions.isEmpty()) {
      return ClickHouseValues.EMPTY_ARRAY_EXPR + "," + ClickHouseValues.EMPTY_ARRAY_EXPR;
    }

    Object[] swatchIds = new Object[swatchOptions.size()];
    Object[][] swatchOptionIds = new Object[swatchOptions.size()][];

    int i = 0;
    for (Map.Entry<String, List<String>> swatchOption : swatchOptions.entrySet()) {
      swatchIds[i] = swatchOption.getKey();
      swatchOptionIds[i] = swatchOption.getValue().toArray(new String[0]);

      i++;
    }
    return ClickHouseValues.convertToSqlExpression(swatchIds)
        + ","
        + ClickHouseValues.convertToSqlExpression(swatchOptionIds);
  }
}
