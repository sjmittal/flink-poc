package com.rh.sku.utils.data;

import com.clickhouse.data.ClickHouseValues;
import com.rh.entity.LiteLocation;
import com.rh.entity.LiteOption;
import com.rh.entity.LiteSwatch;
import java.util.List;
import java.util.Map;

public class DataUtils {

  public static String toNestedSwatchSql(List<LiteSwatch> swatches) {
    if (swatches == null || swatches.isEmpty()) {
      return ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR;
    }

    Object[] swatchIds = new Object[swatches.size()];
    Object[] displayNames = new Object[swatches.size()];
    Object[] adminNames = new Object[swatches.size()];
    Object[] swatchImageRefs = new Object[swatches.size()];

    int i = 0;
    for (LiteSwatch swatch : swatches) {
      swatchIds[i] = swatch.swatchId;
      displayNames[i] = swatch.displayName;
      swatchImageRefs[i] = swatch.swatchImageRef;
      adminNames[i] = swatch.adminName;

      i++;
    }
    return ClickHouseValues.convertToSqlExpression(swatchIds)
        + ","
        + ClickHouseValues.convertToSqlExpression(displayNames)
        + ","
        + ClickHouseValues.convertToSqlExpression(swatchImageRefs)
        + ","
        + ClickHouseValues.convertToSqlExpression(adminNames);
  }

  public static String toNestedOptionSql(List<LiteOption> options) {
    if (options == null || options.isEmpty()) {
      return ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR;
    }

    Object[] optionIds = new Object[options.size()];
    Object[] optionValues = new Object[options.size()];
    Object[] optionTypeIds = new Object[options.size()];
    Object[] optionTypeValues = new Object[options.size()];
    Object[] adminNames = new Object[options.size()];

    int i = 0;
    for (LiteOption option : options) {
      optionIds[i] = option.optionId;
      optionValues[i] = option.optionValue;
      optionTypeIds[i] = option.optionTypeId;
      optionTypeValues[i] = option.optionTypeValue;
      adminNames[i] = option.adminName;

      i++;
    }
    return ClickHouseValues.convertToSqlExpression(optionIds)
        + ","
        + ClickHouseValues.convertToSqlExpression(optionValues)
        + ","
        + ClickHouseValues.convertToSqlExpression(optionTypeIds)
        + ","
        + ClickHouseValues.convertToSqlExpression(optionTypeValues)
        + ","
        + ClickHouseValues.convertToSqlExpression(adminNames);
  }

  public static String toNestedLocationSql(List<LiteLocation> locations) {
    if (locations == null || locations.isEmpty()) {
      return ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR
          + ","
          + ClickHouseValues.EMPTY_ARRAY_EXPR;
    }

    Object[] dcIds = new Object[locations.size()];
    Object[] onHands = new Object[locations.size()];
    Object[] madeToOrders = new Object[locations.size()];

    int i = 0;
    for (LiteLocation location : locations) {
      dcIds[i] = location.dcId;
      onHands[i] = location.onHand;
      madeToOrders[i] = location.madeToOrder;

      i++;
    }
    return ClickHouseValues.convertToSqlExpression(dcIds)
        + ","
        + ClickHouseValues.convertToSqlExpression(onHands)
        + ","
        + ClickHouseValues.convertToSqlExpression(madeToOrders);
  }

  public static String toNestedSql(Map<String, List<String>> swatchOptions) {
    if (swatchOptions == null || swatchOptions.isEmpty()) {
      return ClickHouseValues.EMPTY_ARRAY_EXPR + "," + ClickHouseValues.EMPTY_ARRAY_EXPR;
    }

    Object[] swatchIds = new Object[swatchOptions.size()];
    Object[][] swatchOptionIds = new Object[swatchOptions.size()][];

    int i = 0;
    for (Map.Entry<String, List<String>> swatchOption : swatchOptions.entrySet()) {
      swatchIds[i] = swatchOption.getKey();
      swatchOptionIds[i] = swatchOption.getValue().toArray(new String[0]);

      i++;
    }
    return ClickHouseValues.convertToSqlExpression(swatchIds)
        + ","
        + ClickHouseValues.convertToSqlExpression(swatchOptionIds);
  }
}
