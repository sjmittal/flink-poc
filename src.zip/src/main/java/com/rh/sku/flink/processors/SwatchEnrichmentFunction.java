package com.rh.sku.flink.processors;

import com.rh.entity.EnrichedProductSku;
import com.rh.entity.Swatch;
import java.util.Map;
import org.apache.commons.codec.digest.MurmurHash3;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.apache.flink.util.Collector;

public class SwatchEnrichmentFunction
    extends RichCoFlatMapFunction<
        Tuple4<String, String, String, String>, Swatch, EnrichedProductSku> {

  private MapState<Long, Tuple4<String, String, String, String>> prodSwatchSkuState;
  private ValueState<Swatch> swatchState;

  @Override
  public void open(Configuration config) {

    prodSwatchSkuState =
        getRuntimeContext()
            .getMapState(
                new MapStateDescriptor<>(
                    "saved prod swatch sku",
                    TypeInformation.of(Long.class),
                    TypeInformation.of(new TypeHint<Tuple4<String, String, String, String>>() {})));
    swatchState =
        getRuntimeContext().getState(new ValueStateDescriptor<>("saved swatch", Swatch.class));
  }

  @Override
  public void flatMap1(
      Tuple4<String, String, String, String> skuSwatch, Collector<EnrichedProductSku> collector)
      throws Exception {

    Swatch swatch = swatchState.value();
    if (swatch != null) {
      collector.collect(
          new EnrichedProductSku(skuSwatch.f0, skuSwatch.f1, skuSwatch.f2, skuSwatch.f3, swatch));
    }
    prodSwatchSkuState.put(
        MurmurHash3.hash128x64(
            (skuSwatch.f0 + skuSwatch.f1 + skuSwatch.f2 + skuSwatch.f3).getBytes())[0],
        skuSwatch);
  }

  @Override
  public void flatMap2(Swatch swatch, Collector<EnrichedProductSku> collector) throws Exception {

    Iterable<Map.Entry<Long, Tuple4<String, String, String, String>>> entries =
        prodSwatchSkuState.entries();
    for (Map.Entry<Long, Tuple4<String, String, String, String>> entry : entries) {
      Tuple4<String, String, String, String> skuSwatch = entry.getValue();
      collector.collect(
          new EnrichedProductSku(skuSwatch.f0, skuSwatch.f1, skuSwatch.f2, skuSwatch.f3, swatch));
    }
    swatchState.update(swatch);
  }
}
