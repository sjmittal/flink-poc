package com.rh.sku.flink.processors;

import com.rh.entity.EnrichedProductSku;
import com.rh.entity.SwatchOption;
import java.util.Map;
import org.apache.commons.codec.digest.MurmurHash3;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.apache.flink.util.Collector;

public class SwatchOptEnrichmentFunction
    extends RichCoFlatMapFunction<
        Tuple4<String, String, String, String>, SwatchOption, EnrichedProductSku> {

  private MapState<Integer, Tuple4<String, String, String, String>> prodSwatchOptSkuState;
  private ValueState<SwatchOption> swatchOptionState;

  @Override
  public void open(Configuration config) {

    prodSwatchOptSkuState =
        getRuntimeContext()
            .getMapState(
                new MapStateDescriptor<>(
                    "saved prod swatch opt sku",
                    TypeInformation.of(Integer.class),
                    TypeInformation.of(new TypeHint<Tuple4<String, String, String, String>>() {})));
    swatchOptionState =
        getRuntimeContext()
            .getState(new ValueStateDescriptor<>("saved swatch option", SwatchOption.class));
  }

  @Override
  public void flatMap1(
      Tuple4<String, String, String, String> skuSwatchOpt, Collector<EnrichedProductSku> collector)
      throws Exception {

    SwatchOption swatchOption = swatchOptionState.value();
    if (swatchOption != null) {
      collector.collect(
          new EnrichedProductSku(
              skuSwatchOpt.f0, skuSwatchOpt.f1, skuSwatchOpt.f2, skuSwatchOpt.f3, swatchOption));
    }
    prodSwatchOptSkuState.put(
        MurmurHash3.hash32x86(
            (skuSwatchOpt.f0 + skuSwatchOpt.f1 + skuSwatchOpt.f2 + skuSwatchOpt.f3).getBytes()),
        skuSwatchOpt);
  }

  @Override
  public void flatMap2(SwatchOption swatchOption, Collector<EnrichedProductSku> collector)
      throws Exception {

    Iterable<Map.Entry<Integer, Tuple4<String, String, String, String>>> entries =
        prodSwatchOptSkuState.entries();
    for (Map.Entry<Integer, Tuple4<String, String, String, String>> entry : entries) {
      Tuple4<String, String, String, String> skuSwatchOpt = entry.getValue();
      collector.collect(
          new EnrichedProductSku(
              skuSwatchOpt.f0, skuSwatchOpt.f1, skuSwatchOpt.f2, skuSwatchOpt.f3, swatchOption));
    }
    swatchOptionState.update(swatchOption);
  }
}
