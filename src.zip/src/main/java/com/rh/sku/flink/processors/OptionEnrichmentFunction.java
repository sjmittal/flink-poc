package com.rh.sku.flink.processors;

import com.rh.entity.EnrichedProductSku;
import com.rh.entity.Option;
import java.util.Map;
import org.apache.commons.codec.digest.MurmurHash3;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.apache.flink.util.Collector;

public class OptionEnrichmentFunction
    extends RichCoFlatMapFunction<
        Tuple4<String, String, String, String>, Option, EnrichedProductSku> {

  private MapState<Integer, Tuple4<String, String, String, String>> prodOptionSkuState;
  private ValueState<Option> optionState;

  @Override
  public void open(Configuration config) {

    prodOptionSkuState =
        getRuntimeContext()
            .getMapState(
                new MapStateDescriptor<>(
                    "saved prod option sku",
                    TypeInformation.of(Integer.class),
                    TypeInformation.of(new TypeHint<Tuple4<String, String, String, String>>() {})));
    optionState =
        getRuntimeContext().getState(new ValueStateDescriptor<>("saved option", Option.class));
  }

  @Override
  public void flatMap1(
      Tuple4<String, String, String, String> skuOption, Collector<EnrichedProductSku> collector)
      throws Exception {

    Option option = optionState.value();
    if (option != null) {
      collector.collect(
          new EnrichedProductSku(skuOption.f0, skuOption.f1, skuOption.f2, skuOption.f3, option));
    }
    prodOptionSkuState.put(
        MurmurHash3.hash32x86(
            (skuOption.f0 + skuOption.f1 + skuOption.f2 + skuOption.f3).getBytes()),
        skuOption);
  }

  @Override
  public void flatMap2(Option option, Collector<EnrichedProductSku> collector) throws Exception {

    Iterable<Map.Entry<Integer, Tuple4<String, String, String, String>>> entries =
        prodOptionSkuState.entries();
    for (Map.Entry<Integer, Tuple4<String, String, String, String>> entry : entries) {
      Tuple4<String, String, String, String> skuOption = entry.getValue();
      collector.collect(
          new EnrichedProductSku(skuOption.f0, skuOption.f1, skuOption.f2, skuOption.f3, option));
    }
    optionState.update(option);
  }
}
