package com.rh.sku.flink.processors;

import static com.rh.sku.flink.ProcessorMain.prodSkuOptionTag;
import static com.rh.sku.flink.ProcessorMain.prodSkuSwatchTag;

import com.rh.entity.ProductSku;
import java.util.Set;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;

public class ProductSkuProcessor
    extends KeyedProcessFunction<Integer, ProductSku, Tuple3<String, String, String>> {

  @Override
  public void processElement(
      ProductSku productSku,
      KeyedProcessFunction<Integer, ProductSku, Tuple3<String, String, String>>.Context context,
      Collector<Tuple3<String, String, String>> collector) {
    String productId = productSku.productId;
    String region = productSku.region;

    productSku.itemFullSkuIds.entrySet().stream()
        .flatMap(e -> e.getValue().stream())
        .forEach(
            s -> {
              String fullSkuId = s.fullSkuId;
              Set<String> options = s.totalOptionIds;
              Set<String> swatches = s.totalOptionIds;

              options.forEach(
                  o -> {
                    context.output(prodSkuOptionTag, Tuple4.of(productId, fullSkuId, region, o));
                  });

              swatches.forEach(
                  sw -> {
                    context.output(prodSkuSwatchTag, Tuple4.of(productId, fullSkuId, region, sw));
                  });

              collector.collect(Tuple3.of(productId, fullSkuId, region));
            });
  }
}
