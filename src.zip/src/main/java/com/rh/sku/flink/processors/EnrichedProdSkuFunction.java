package com.rh.sku.flink.processors;

import com.rh.entity.EnrichedProductSku;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;

public class EnrichedProdSkuFunction
    extends KeyedProcessFunction<Integer, EnrichedProductSku, EnrichedProductSku> {

  private ValueState<EnrichedProductSku> enrichedState;

  @Override
  public void open(Configuration config) {

    enrichedState =
        getRuntimeContext()
            .getState(new ValueStateDescriptor<>("enriched prod sku", EnrichedProductSku.class));
  }

  @Override
  public void processElement(
      EnrichedProductSku enrichedProdSku,
      KeyedProcessFunction<Integer, EnrichedProductSku, EnrichedProductSku>.Context context,
      Collector<EnrichedProductSku> collector)
      throws Exception {
    EnrichedProductSku enrichedData = enrichedState.value();
    if (enrichedData != null) {
      EnrichedProductSku updatedEnrichedProdSku = enrichedData.update(enrichedProdSku);
      enrichedState.update(updatedEnrichedProdSku);
      collector.collect(updatedEnrichedProdSku);
    } else {
      enrichedState.update(enrichedProdSku);
      collector.collect(enrichedProdSku);
    }
  }
}
