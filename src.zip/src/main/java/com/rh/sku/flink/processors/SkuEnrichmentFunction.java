package com.rh.sku.flink.processors;

import com.rh.entity.EnrichedProductSku;
import com.rh.entity.Product;
import java.util.Map;
import org.apache.commons.codec.digest.MurmurHash3;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.apache.flink.util.Collector;

public class SkuEnrichmentFunction
    extends RichCoFlatMapFunction<Tuple3<String, String, String>, Product, EnrichedProductSku> {
  private MapState<Integer, Tuple3<String, String, String>> prodSkuState;
  private ValueState<Product> productState;

  @Override
  public void open(Configuration config) {

    prodSkuState =
        getRuntimeContext()
            .getMapState(
                new MapStateDescriptor<>(
                    "saved prod sku",
                    TypeInformation.of(Integer.class),
                    TypeInformation.of(new TypeHint<Tuple3<String, String, String>>() {})));
    productState =
        getRuntimeContext().getState(new ValueStateDescriptor<>("saved product", Product.class));
  }

  @Override
  public void flatMap1(Tuple3<String, String, String> sku, Collector<EnrichedProductSku> out)
      throws Exception {

    Product product = productState.value();
    if (product != null) {
      out.collect(new EnrichedProductSku(sku.f0, sku.f1, sku.f2, product));
    }
    prodSkuState.put(MurmurHash3.hash32x86((sku.f0 + sku.f1 + sku.f2).getBytes()), sku);
  }

  @Override
  public void flatMap2(Product product, Collector<EnrichedProductSku> out) throws Exception {

    Iterable<Map.Entry<Integer, Tuple3<String, String, String>>> entries = prodSkuState.entries();
    for (Map.Entry<Integer, Tuple3<String, String, String>> entry : entries) {
      Tuple3<String, String, String> sku = entry.getValue();
      out.collect(new EnrichedProductSku(sku.f0, sku.f1, sku.f2, product));
    }
    productState.update(product);
  }
}
