package com.rh.sku.flink.processors;

import static com.rh.sku.utils.data.DataUtils.toDateTime;
import static com.rh.sku.utils.data.DataUtils.toNestedLocationSql;
import static com.rh.sku.utils.data.DataUtils.toNestedOptionSql;
import static com.rh.sku.utils.data.DataUtils.toNestedSql;
import static com.rh.sku.utils.data.DataUtils.toNestedSwatchSql;

import com.clickhouse.data.ClickHouseValues;
import com.rh.entity.CombinedData;
import java.util.ArrayList;
import java.util.List;
import ru.ivi.opensource.flinkclickhousesink.ClickHouseSinkConverter;

public class CombinedSkuConvertor implements ClickHouseSinkConverter<CombinedData> {

  @Override
  public String convert(CombinedData combinedData) {
    List<String> clickHouseValues = new ArrayList<>();
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.productId));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.fullSkuId));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.region));

    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.productDisplayName));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.adminName));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.imageToken));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.galleryDescription));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.keywords));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.source));
    clickHouseValues.add(
        ClickHouseValues.convertToSqlExpression(toDateTime(combinedData.startDate)));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(toDateTime(combinedData.endDate)));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.category));
    clickHouseValues.add(toNestedSwatchSql(combinedData.swatches));
    clickHouseValues.add(toNestedOptionSql(combinedData.options));
    clickHouseValues.add(toNestedSql(combinedData.swatchOptions));

    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.webPurchasable));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.dropship));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.itemNumber));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.colorCode));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.itemDescription));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.department));
    clickHouseValues.add(
        ClickHouseValues.convertToSqlExpression(combinedData.sellToCountryRegionCode));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.mddFabric));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.mddColor));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.mddFunction));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.mddDetail));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.mddFrame));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.mddDepth));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.mddItemSize));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.mddFill));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.mddSecondaryColor));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.mddItemStyle));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.mddCollection));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.countryCode));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.currencyCode));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.sellToCountryRegion));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.memberPrice));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.contractPrice));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.tradePrice));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.saleStatus));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.listPrice));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.salePrice));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.memberListPrice));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.retailOriginalPrice));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.retailCurrentPrice));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.outletOriginalPrice));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.price));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.effectiveStartDate));
    clickHouseValues.add(toNestedLocationSql(combinedData.locations));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.inStock));
    clickHouseValues.add(ClickHouseValues.convertToSqlExpression(combinedData.availablityStatus));
    clickHouseValues.add(
        ClickHouseValues.convertToSqlExpression(combinedData.availablityStatusMsg));

    return "(" + String.join(",", clickHouseValues) + ")";
  }
}
