package com.rh.sku.flink.processors;

import com.rh.entity.EnrichedSku;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;

public class EnrichedSkuFunction extends KeyedProcessFunction<Integer, EnrichedSku, EnrichedSku> {

  private ValueState<EnrichedSku> enrichedState;

  @Override
  public void open(Configuration config) {

    enrichedState =
        getRuntimeContext().getState(new ValueStateDescriptor<>("enriched sku", EnrichedSku.class));
  }

  @Override
  public void processElement(
      EnrichedSku enrichedSku,
      KeyedProcessFunction<Integer, EnrichedSku, EnrichedSku>.Context context,
      Collector<EnrichedSku> collector)
      throws Exception {
    EnrichedSku enrichedData = enrichedState.value();
    if (enrichedData != null) {
      EnrichedSku updatedEnrichedSku = enrichedData.update(enrichedSku);
      enrichedState.update(updatedEnrichedSku);
      collector.collect(updatedEnrichedSku);
    } else {
      enrichedState.update(enrichedSku);
      collector.collect(enrichedSku);
    }
  }
}
