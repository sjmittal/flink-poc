package com.rh.sku.flink.processors;

import com.rh.entity.CombinedData;
import com.rh.entity.EnrichedProductSku;
import com.rh.entity.EnrichedSku;
import java.util.Map;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.apache.flink.util.Collector;

public class CombinedSkuFunction
    extends RichCoFlatMapFunction<EnrichedProductSku, EnrichedSku, CombinedData> {

  private MapState<String, EnrichedProductSku> enrichedProductSkuState;
  private ValueState<EnrichedSku> enrichedSkuState;

  @Override
  public void open(Configuration config) {

    enrichedProductSkuState =
        getRuntimeContext()
            .getMapState(
                new MapStateDescriptor<>(
                    "saved enriched product sku",
                    TypeInformation.of(String.class),
                    Types.POJO(EnrichedProductSku.class)));
    enrichedSkuState =
        getRuntimeContext()
            .getState(new ValueStateDescriptor<>("saved enriched sku", EnrichedSku.class));
  }

  @Override
  public void flatMap1(EnrichedProductSku enrichedProductSku, Collector<CombinedData> out)
      throws Exception {

    EnrichedSku enrichedSku = enrichedSkuState.value();
    if (enrichedSku != null) {
      out.collect(new CombinedData(enrichedProductSku, enrichedSku));
    }
    enrichedProductSkuState.put(enrichedProductSku.productId, enrichedProductSku);
  }

  @Override
  public void flatMap2(EnrichedSku enrichedSku, Collector<CombinedData> out) throws Exception {

    Iterable<Map.Entry<String, EnrichedProductSku>> entries = enrichedProductSkuState.entries();
    for (Map.Entry<String, EnrichedProductSku> entry : entries) {
      EnrichedProductSku enrichedProductSku = entry.getValue();
      out.collect(new CombinedData(enrichedProductSku, enrichedSku));
    }
    enrichedSkuState.update(enrichedSku);
  }
}
