package com.rh.sku.flink;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.rh.entity.CombinedData;
import com.rh.entity.EnrichedProductSku;
import com.rh.entity.EnrichedSku;
import com.rh.entity.EpimSku;
import com.rh.entity.Inventory;
import com.rh.entity.Option;
import com.rh.entity.Pricing;
import com.rh.entity.Product;
import com.rh.entity.ProductSku;
import com.rh.entity.Swatch;
import com.rh.entity.SwatchOption;
import com.rh.sku.flink.processors.CombinedSkuConvertor;
import com.rh.sku.flink.processors.CombinedSkuFunction;
import com.rh.sku.flink.processors.EnrichedProdSkuFunction;
import com.rh.sku.flink.processors.EnrichedSkuFunction;
import com.rh.sku.flink.processors.OptionEnrichmentFunction;
import com.rh.sku.flink.processors.ProductSkuProcessor;
import com.rh.sku.flink.processors.SkuEnrichmentFunction;
import com.rh.sku.flink.processors.SwatchEnrichmentFunction;
import com.rh.sku.flink.processors.SwatchOptEnrichmentFunction;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import org.apache.commons.codec.digest.MurmurHash3;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.cdc.connectors.base.options.StartupOptions;
import org.apache.flink.cdc.connectors.mongodb.source.MongoDBSource;
import org.apache.flink.cdc.debezium.DebeziumDeserializationSchema;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;
import org.apache.kafka.connect.data.Struct;
import org.apache.kafka.connect.source.SourceRecord;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.ivi.opensource.flinkclickhousesink.ClickHouseSink;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseClusterSettings;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseSinkConst;

public class ProcessorMain {

  public static final OutputTag<Tuple4<String, String, String, String>> prodSkuSwatchTag =
      new OutputTag<Tuple4<String, String, String, String>>("pro_sku_swatch") {};
  public static final OutputTag<Tuple4<String, String, String, String>> prodSkuOptionTag =
      new OutputTag<Tuple4<String, String, String, String>>("pro_sku_swatch") {};

  private static final Logger logger = LoggerFactory.getLogger(ProcessorMain.class);

  private static final Gson gson = new Gson();

  private static final String USERNAME = "sachinm";
  private static final String PASSWORD = "sachinm";
  private static final String SCHEME = "mongodb+srv";
  private static final String HOSTNAME = "cluster0.tee4p.mongodb.net";
  private static final String MONGO_URI =
      SCHEME + "://" + USERNAME + ":" + PASSWORD + "@" + HOSTNAME;
  private static final String MONGO_DB = "rh-doat2-service-development";

  public static void main(String[] args) throws Exception {

    final ParameterTool params = ParameterTool.fromArgs(args);
    System.out.println(params.toMap());

    Map<String, String> globalParameters = new HashMap<>();
    // ClickHouse cluster properties
    globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_HOSTS, "http://localhost:8123");
    globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_USER, "default");
    globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_PASSWORD, "");
    // sink common
    globalParameters.put(ClickHouseSinkConst.TIMEOUT_SEC, "60");
    globalParameters.put(ClickHouseSinkConst.FAILED_RECORDS_PATH, "/tmp/failed_records");
    globalParameters.put(ClickHouseSinkConst.NUM_WRITERS, "3");
    globalParameters.put(ClickHouseSinkConst.NUM_RETRIES, "3");
    globalParameters.put(ClickHouseSinkConst.QUEUE_MAX_CAPACITY, "10000");
    globalParameters.put(
        ClickHouseSinkConst.IGNORING_CLICKHOUSE_SENDING_EXCEPTION_ENABLED, "false");
    ParameterTool globalParams = ParameterTool.fromMap(globalParameters);

    Configuration configuration = new Configuration();
    final StreamExecutionEnvironment env =
        StreamExecutionEnvironment.getExecutionEnvironment(configuration);
    env.enableCheckpointing(300000L);
    env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
    env.getCheckpointConfig().setMinPauseBetweenCheckpoints(60000L);
    env.getCheckpointConfig().setCheckpointTimeout(60000L);
    env.getCheckpointConfig().setTolerableCheckpointFailureNumber(Integer.MAX_VALUE);
    env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
    env.getCheckpointConfig().enableUnalignedCheckpoints();

    env.getConfig().disableGenericTypes();
    env.getConfig().setGlobalJobParameters(globalParams);

    MongoDBSource<ProductSku> prodSkuSource =
        getSourceCDC(ProductSku.class, "RH_PRODUCTS_SKUS_IN_REVIEW");

    MongoDBSource<Product> productSource = getSourceCDC(Product.class, "RH_CM_PRODUCTS");

    MongoDBSource<Swatch> swatchSource = getSourceCDC(Swatch.class, "RH_CM_SWATCHES");

    MongoDBSource<SwatchOption> swatchOptSource =
        getSourceCDC(SwatchOption.class, "RH_CM_SWATCH_OPTIONS");

    MongoDBSource<Option> optionSource = getSourceCDC(Option.class, "RH_CM_OPTIONS");

    MongoDBSource<EpimSku> skuSource = getSourceCDC(EpimSku.class, "RH_EPIM_SKUS");

    MongoDBSource<Pricing> pricingSource = getSourceCDC(Pricing.class, "RH_PRICING");

    MongoDBSource<Inventory> inventorySource = getSourceCDC(Inventory.class, "RH_INVENTORY");

    final SingleOutputStreamOperator<Tuple3<String, String, String>> prodSkuEvents =
        env.fromSource(prodSkuSource, WatermarkStrategy.noWatermarks(), "ProdSkuSrc")
            .filter(ps -> ps.productId != null && ps.region != null)
            .keyBy(ps -> MurmurHash3.hash128x64((ps.productId + ps.region).getBytes())[0])
            .process(new ProductSkuProcessor())
            .name("ProdSkuProc");

    DataStream<Tuple4<String, String, String, String>> prodSkuOptions =
        prodSkuEvents.getSideOutput(prodSkuOptionTag);
    DataStream<Tuple4<String, String, String, String>> prodSkuSwatches =
        prodSkuEvents.getSideOutput(prodSkuSwatchTag);

    final DataStream<Product> productEvents =
        env.fromSource(productSource, WatermarkStrategy.noWatermarks(), "ProdSrc")
            .filter(p -> p.productId != null);

    DataStream<EnrichedProductSku> prodSkuData =
        prodSkuEvents
            .connect(productEvents)
            .keyBy(ps -> ps.f0, p -> p.productId)
            .flatMap(new SkuEnrichmentFunction())
            .name("ProdEnrich");

    final DataStream<Swatch> swatchEvents =
        env.fromSource(swatchSource, WatermarkStrategy.noWatermarks(), "SwatchSrc")
            .filter(sw -> sw.swatchId != null);
    DataStream<EnrichedProductSku> swatchSkuData =
        prodSkuSwatches
            .connect(swatchEvents)
            .keyBy(pss -> pss.f3, sw -> sw.swatchId)
            .flatMap(new SwatchEnrichmentFunction())
            .name("SwatchEnrich");

    final DataStream<SwatchOption> swatchOptEvents =
        env.fromSource(swatchOptSource, WatermarkStrategy.noWatermarks(), "SwatchOptSrc")
            .filter(so -> so.swatchId != null);
    DataStream<EnrichedProductSku> swatchOptSkuData =
        prodSkuSwatches
            .connect(swatchOptEvents)
            .keyBy(pss -> pss.f3, so -> so.swatchId)
            .flatMap(new SwatchOptEnrichmentFunction())
            .name("SwatchOptEnrich");

    final DataStream<Option> optionsEvents =
        env.fromSource(optionSource, WatermarkStrategy.noWatermarks(), "OptionSrc")
            .filter(o -> o.optionId != null && o.optionTypeId != null);
    DataStream<EnrichedProductSku> optionSkuData =
        prodSkuOptions
            .connect(optionsEvents)
            .keyBy(pso -> pso.f3, o -> o.optionId)
            .flatMap(new OptionEnrichmentFunction())
            .name("OptionEnrich");

    DataStream<EnrichedProductSku> enrichedProdSkuData =
        prodSkuData
            .union(swatchSkuData, swatchOptSkuData, optionSkuData)
            .keyBy(
                e -> MurmurHash3.hash128x64((e.productId + e.fullSkuId + e.region).getBytes())[0])
            .process(new EnrichedProdSkuFunction())
            .name("EnrichProdSku");

    final DataStream<EpimSku> skuEvents =
        env.fromSource(skuSource, WatermarkStrategy.noWatermarks(), "SkuSrc")
            .filter(s -> s.fullSkuId != null && s.region != null);

    final DataStream<Pricing> pricingEvents =
        env.fromSource(pricingSource, WatermarkStrategy.noWatermarks(), "PriceSrc")
            .filter(p -> p.fullSkuId != null && p.region != null);

    final DataStream<Inventory> inventoryEvents =
        env.fromSource(inventorySource, WatermarkStrategy.noWatermarks(), "InvSrc")
            .filter(i -> i.fullSkuId != null && i.region != null);

    DataStream<EnrichedSku> skuData = skuEvents.map(EnrichedSku::new);
    DataStream<EnrichedSku> skuPricingData = pricingEvents.map(EnrichedSku::new);
    DataStream<EnrichedSku> skuInventoryData = inventoryEvents.map(EnrichedSku::new);
    DataStream<EnrichedSku> enrichedSkuData =
        skuData
            .union(skuPricingData, skuInventoryData)
            .keyBy(e -> MurmurHash3.hash128x64((e.fullSkuId + e.region).getBytes())[0])
            .process(new EnrichedSkuFunction())
            .name("EnrichSku");

    DataStream<CombinedData> combinedData =
        enrichedProdSkuData
            .connect(enrichedSkuData)
            .keyBy(
                ps -> MurmurHash3.hash128x64((ps.fullSkuId + ps.region).getBytes())[0],
                s -> MurmurHash3.hash128x64((s.fullSkuId + s.region).getBytes())[0])
            .flatMap(new CombinedSkuFunction())
            .returns(Types.POJO(CombinedData.class))
            .name("CombProc");

    Properties payloadsProps = new Properties();
    payloadsProps.put(ClickHouseSinkConst.TARGET_TABLE_NAME, "combined_sku");
    payloadsProps.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, "10000");
    combinedData
        .keyBy(c -> MurmurHash3.hash128x64((c.productId + c.fullSkuId + c.region).getBytes())[0])
        .addSink(new ClickHouseSink<>(payloadsProps, new CombinedSkuConvertor()))
        .name("Sink");

    // execute program
    env.execute("SkuProcExec");
  }

  private static <T> MongoDBSource<T> getSourceCDC(Class<T> clazz, String collectionName) {
    return MongoDBSource.<T>builder()
        .hosts(HOSTNAME)
        .scheme(SCHEME)
        .databaseList(MONGO_DB)
        .collectionList(MONGO_DB + "." + collectionName)
        .username(USERNAME)
        .password(PASSWORD)
        .startupOptions(StartupOptions.initial())
        .batchSize(2048)
        .closeIdleReaders(true)
        .deserializer(
            new DebeziumDeserializationSchema<T>() {
              @Override
              public void deserialize(SourceRecord record, Collector<T> collector) {
                Optional.ofNullable(record)
                    .map(SourceRecord::value)
                    .map(Struct.class::cast)
                    .map(struct -> struct.getString("fullDocument"))
                    .map(Document::parse)
                    .map(document -> toType(document, clazz))
                    .ifPresent(collector::collect);
              }

              @Override
              public TypeInformation<T> getProducedType() {
                return Types.POJO(clazz);
              }
            })
        .build();
  }

  private static <T> T toType(Document document, Class<T> clazz) {
    String json = document.toJson();
    T data = null;
    try {
      data = gson.fromJson(json, clazz);
    } catch (JsonSyntaxException e) {
      logger.error("Error decoding {} {}", clazz, json, e);
    }
    return data;
  }
}
