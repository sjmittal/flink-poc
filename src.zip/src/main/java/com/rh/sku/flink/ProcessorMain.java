package com.rh.sku.flink;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.rh.entity.CombinedData;
import com.rh.entity.EnrichedProductSku;
import com.rh.entity.EnrichedSku;
import com.rh.entity.EpimSku;
import com.rh.entity.Inventory;
import com.rh.entity.Option;
import com.rh.entity.Pricing;
import com.rh.entity.Product;
import com.rh.entity.ProductSku;
import com.rh.entity.Swatch;
import com.rh.entity.SwatchOption;
import com.rh.sku.flink.processors.CombinedSkuConvertor;
import com.rh.sku.flink.processors.CombinedSkuFunction;
import com.rh.sku.flink.processors.EnrichedProdSkuFunction;
import com.rh.sku.flink.processors.EnrichedSkuFunction;
import com.rh.sku.flink.processors.OptionEnrichmentFunction;
import com.rh.sku.flink.processors.ProductSkuProcessor;
import com.rh.sku.flink.processors.SkuEnrichmentFunction;
import com.rh.sku.flink.processors.SwatchEnrichmentFunction;
import com.rh.sku.flink.processors.SwatchOptEnrichmentFunction;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.apache.commons.codec.digest.MurmurHash3;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.configuration.MemorySize;
import org.apache.flink.connector.mongodb.source.MongoSource;
import org.apache.flink.connector.mongodb.source.enumerator.splitter.PartitionStrategy;
import org.apache.flink.connector.mongodb.source.reader.deserializer.MongoDeserializationSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.OutputTag;
import org.bson.BsonDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.ivi.opensource.flinkclickhousesink.ClickHouseSink;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseClusterSettings;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseSinkConst;

public class ProcessorMain {

  public static final OutputTag<Tuple4<String, String, String, String>> prodSkuSwatchTag =
      new OutputTag<Tuple4<String, String, String, String>>("pro_sku_swatch") {};

  public static final OutputTag<Tuple4<String, String, String, String>> prodSkuOptionTag =
      new OutputTag<Tuple4<String, String, String, String>>("pro_sku_swatch") {};
  private static final Logger logger = LoggerFactory.getLogger(ProcessorMain.class);
  private static final Gson gson = new Gson();
  private static final String MONGO_URI =
      "mongodb+srv://sachinm:sachinm@cluster0.tee4p.mongodb.net";
  private static final String MONGO_DB = "rh-doat2-service-development";

  public static void main(String[] args) throws Exception {

    final ParameterTool params = ParameterTool.fromArgs(args);
    System.out.println(params.toMap());

    Map<String, String> globalParameters = new HashMap<>();
    // ClickHouse cluster properties
    globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_HOSTS, "http://localhost:8123");
    globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_USER, "default");
    globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_PASSWORD, "");
    // sink common
    globalParameters.put(ClickHouseSinkConst.TIMEOUT_SEC, "60");
    globalParameters.put(ClickHouseSinkConst.FAILED_RECORDS_PATH, "/tmp/failed_records");
    globalParameters.put(ClickHouseSinkConst.NUM_WRITERS, "3");
    globalParameters.put(ClickHouseSinkConst.NUM_RETRIES, "3");
    globalParameters.put(ClickHouseSinkConst.QUEUE_MAX_CAPACITY, "10000");
    globalParameters.put(
        ClickHouseSinkConst.IGNORING_CLICKHOUSE_SENDING_EXCEPTION_ENABLED, "false");
    ParameterTool globalParams = ParameterTool.fromMap(globalParameters);

    Configuration configuration = new Configuration();
    final StreamExecutionEnvironment env =
        StreamExecutionEnvironment.getExecutionEnvironment(configuration);
    env.enableCheckpointing(60000L);
    env.getConfig().disableGenericTypes();
    env.getConfig().setGlobalJobParameters(globalParams);

    MongoSource<ProductSku> prodSkuSource =
        getSource(ProductSku.class, "RH_PRODUCTS_SKUS_IN_REVIEW");

    MongoSource<Product> productSource = getSource(Product.class, "RH_CM_PRODUCTS");

    MongoSource<Swatch> swatchSource = getSource(Swatch.class, "RH_CM_SWATCHES");

    MongoSource<SwatchOption> swatchOptSource =
        getSource(SwatchOption.class, "RH_CM_SWATCH_OPTIONS");

    MongoSource<Option> optionSource = getSource(Option.class, "RH_CM_OPTIONS");

    MongoSource<EpimSku> skuSource = getSource(EpimSku.class, "RH_CM_PRODUCTS");

    MongoSource<Pricing> pricingSource = getSource(Pricing.class, "RH_PRICING");

    MongoSource<Inventory> inventorySource = getSource(Inventory.class, "RH_INVENTORY");

    final SingleOutputStreamOperator<Tuple3<String, String, String>> prodSkuEvents =
        env.fromSource(prodSkuSource, WatermarkStrategy.noWatermarks(), "ProdSkuSrc")
            .filter(ps -> ps.productId != null && ps.region != null)
            .keyBy(ps -> MurmurHash3.hash32x86((ps.productId + ps.region).getBytes()))
            .process(new ProductSkuProcessor())
            .name("ProdSkuProc");

    DataStream<Tuple4<String, String, String, String>> prodSkuOptions =
        prodSkuEvents.getSideOutput(prodSkuOptionTag);
    DataStream<Tuple4<String, String, String, String>> prodSkuSwatches =
        prodSkuEvents.getSideOutput(prodSkuSwatchTag);

    final DataStream<Product> productEvents =
        env.fromSource(productSource, WatermarkStrategy.noWatermarks(), "ProdSrc")
            .filter(p -> p.productId != null);

    DataStream<EnrichedProductSku> prodSkuData =
        prodSkuEvents
            .connect(productEvents)
            .keyBy(ps -> ps.f0, p -> p.productId)
            .flatMap(new SkuEnrichmentFunction())
            .name("ProdEnrich");

    final DataStream<Swatch> swatchEvents =
        env.fromSource(swatchSource, WatermarkStrategy.noWatermarks(), "SwatchSrc")
            .filter(sw -> sw.swatchId != null);
    DataStream<EnrichedProductSku> swatchSkuData =
        prodSkuSwatches
            .connect(swatchEvents)
            .keyBy(pss -> pss.f3, sw -> sw.swatchId)
            .flatMap(new SwatchEnrichmentFunction())
            .name("SwatchEnrich");

    final DataStream<SwatchOption> swatchOptEvents =
        env.fromSource(swatchOptSource, WatermarkStrategy.noWatermarks(), "SwatchOptSrc")
            .filter(so -> so.swatchId != null);
    DataStream<EnrichedProductSku> swatchOptSkuData =
        prodSkuSwatches
            .connect(swatchOptEvents)
            .keyBy(pss -> pss.f3, so -> so.swatchId)
            .flatMap(new SwatchOptEnrichmentFunction())
            .name("SwatchOptEnrich");

    final DataStream<Option> optionsEvents =
        env.fromSource(optionSource, WatermarkStrategy.noWatermarks(), "OptionSrc")
            .filter(o -> o.optionId != null && o.optionTypeId != null);
    DataStream<EnrichedProductSku> optionSkuData =
        prodSkuOptions
            .connect(optionsEvents)
            .keyBy(pso -> pso.f3, o -> o.optionId)
            .flatMap(new OptionEnrichmentFunction())
            .name("OptionEnrich");

    DataStream<EnrichedProductSku> enrichedProdSkuData =
        prodSkuData
            .union(swatchSkuData, swatchOptSkuData, optionSkuData)
            .keyBy(e -> MurmurHash3.hash32x86((e.productId + e.fullSkuId + e.region).getBytes()))
            .process(new EnrichedProdSkuFunction())
            .name("EnrichProdSku");

    final DataStream<EpimSku> skuEvents =
        env.fromSource(skuSource, WatermarkStrategy.noWatermarks(), "SkuSrc")
            .filter(s -> s.fullSkuId != null && s.region != null);

    final DataStream<Pricing> pricingEvents =
        env.fromSource(pricingSource, WatermarkStrategy.noWatermarks(), "PriceSrc")
            .filter(p -> p.fullSkuId != null && p.region != null);

    final DataStream<Inventory> inventoryEvents =
        env.fromSource(inventorySource, WatermarkStrategy.noWatermarks(), "InvSrc")
            .filter(i -> i.fullSkuId != null && i.region != null);

    DataStream<EnrichedSku> skuData = skuEvents.map(EnrichedSku::new);
    DataStream<EnrichedSku> skuPricingData = pricingEvents.map(EnrichedSku::new);
    DataStream<EnrichedSku> skuInventoryData = inventoryEvents.map(EnrichedSku::new);
    DataStream<EnrichedSku> enrichedSkuData =
        skuData
            .union(skuPricingData, skuInventoryData)
            .keyBy(e -> MurmurHash3.hash32x86((e.fullSkuId + e.region).getBytes()))
            .process(new EnrichedSkuFunction())
            .name("EnrichSku");

    DataStream<CombinedData> combinedData =
        enrichedProdSkuData
            .connect(enrichedSkuData)
            .keyBy(
                ps -> MurmurHash3.hash32x86((ps.fullSkuId + ps.region).getBytes()),
                s -> MurmurHash3.hash32x86((s.fullSkuId + s.region).getBytes()))
            .flatMap(new CombinedSkuFunction())
            .returns(Types.POJO(CombinedData.class))
            .name("CombProc");

    Properties payloadsProps = new Properties();
    payloadsProps.put(ClickHouseSinkConst.TARGET_TABLE_NAME, "combined_sku");
    payloadsProps.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, "10000");
    combinedData
        .keyBy(c -> MurmurHash3.hash32x86((c.productId + c.fullSkuId + c.region).getBytes()))
        .addSink(new ClickHouseSink<>(payloadsProps, new CombinedSkuConvertor()))
        .name("Sink");

    // execute program
    env.execute("SkuProcExec");
  }

  private static <T> MongoSource<T> getSource(Class<T> clazz, String collectionName) {
    return MongoSource.<T>builder()
        .setUri(MONGO_URI)
        .setDatabase(MONGO_DB)
        .setCollection(collectionName)
        .setFetchSize(2048)
        .setNoCursorTimeout(true)
        .setPartitionStrategy(PartitionStrategy.SAMPLE)
        .setPartitionSize(MemorySize.ofMebiBytes(64))
        .setSamplesPerPartition(10)
        .setDeserializationSchema(
            new MongoDeserializationSchema<T>() {
              @Override
              public T deserialize(BsonDocument document) {
                String json = document.toJson();
                T data = null;
                try {
                  data = gson.fromJson(json, clazz);
                } catch (JsonSyntaxException e) {
                  logger.error("Error decoding {} {}", clazz, json, e);
                }
                return data;
              }

              @Override
              public TypeInformation<T> getProducedType() {
                return Types.POJO(clazz);
              }
            })
        .build();
  }
}
